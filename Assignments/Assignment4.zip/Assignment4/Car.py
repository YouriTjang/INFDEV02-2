﻿import pygame
from Node import *

#PUT YOUR CAR STRUCTURE CODE HERE

#Hint POSITION...a car lies on a tile...